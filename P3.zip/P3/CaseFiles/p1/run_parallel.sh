cd ../P2Geo
./uniqueSTL.X
cp total.fms ../P2Case
cd ../P2Case
cartesianMesh
transformPoints -scale 1e-3
decomposePar -force
mpirun -np 3 simpleFoam -parallel > log.simpleFoam && tail -f log.simpleFoam
