cd ../p1Geo
./uniqueSTL.X
cp total.fms ../p1
cd ../p1
cartesianMesh
transformPoints -scale 1e-3
simpleFoam
